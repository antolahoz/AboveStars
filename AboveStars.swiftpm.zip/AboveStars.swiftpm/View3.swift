//
//  View3.swift
//  WWDC_Finale
//
//  Created by Antonio Lahoz on 20/04/23.
//

import SwiftUI
import SceneKit

struct View3: View {
    
    var body: some View {
        ZStack{
            
            Image("View2_3")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .scaledToFill()
            
            
            NavigationLink(destination: View4().navigationBarBackButtonHidden()
            ){
                
                Text("Continue")
                    .frame(width: 100.0, height: 50.0)
                    
                    .background(Color(.systemBlue))
                    .cornerRadius(10)
                    .foregroundColor(.white)
                    .buttonStyle(.bordered)
                    .padding(.top, 700.0)
                    .padding(.leading, 950.0)
            }
            
            
        
        }
    }
}

struct View3_Previews: PreviewProvider {
    static var previews: some View {
        View3()
    }
}
