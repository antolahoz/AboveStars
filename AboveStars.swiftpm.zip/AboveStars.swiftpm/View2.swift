//
//  View2.swift
//  WWDC_Finale
//
//  Created by Antonio Lahoz on 19/04/23.
//

import SwiftUI

struct View2: View {
    var body: some View {
        ZStack{
            
            Image("View1_2")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .scaledToFill()
            
            
            NavigationLink(destination: View3().navigationBarBackButtonHidden()
            ){
                
                Text("Continue")
                    .frame(width: 100.0, height: 50.0)
                    
                    .background(Color(.systemBlue))
                    .cornerRadius(10)
                    .foregroundColor(.white)
                    .buttonStyle(.bordered)
                    .padding(.top, 700.0)
                    .padding(.leading, 950.0)
            }
        }
    }
}

struct View2_Previews: PreviewProvider {
    static var previews: some View {
        View2()
    }
}
