//
//  View3.swift
//  WWDC_Finale
//
//  Created by Antonio Lahoz on 20/04/23.
//

import SwiftUI
import SceneKit

struct View5: View {
    
    var body: some View {
        ZStack{
            
            Image("View4")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .scaledToFill()
        }
    }
}

struct View5_Previews: PreviewProvider {
    static var previews: some View {
        View5()
    }
}
