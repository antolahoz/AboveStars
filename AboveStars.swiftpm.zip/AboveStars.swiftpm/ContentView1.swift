//
//  ContentView1.swift
//  WWDC_Finale
//
//  Created by Antonio Lahoz on 20/04/23.
//

import SwiftUI

struct ContentView1: View {
    var body: some View {
        NavigationView(){
            ZStack{
                
                Image("View0_4")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .scaledToFill()
                
                
                NavigationLink(destination: View2().navigationBarBackButtonHidden()
                ){
                    Image("Planet")
                        .resizable()
                        .frame(width: 350.0, height: 350.0)
                        .padding(.top, 80.0)
//                    Text("Start")
//                        .frame(width: 100.0, height: 50.0)
//
//                        .background(Color(red: 181/255, green: 145/255, blue: 250/255, opacity: 1.0))
//                        .cornerRadius(10)
//                        .foregroundColor(.white)
//                        .buttonStyle(.bordered)
//                        .padding(.top, 700.0)
//                        .padding(.leading, 950.0)
                }
                 
                
                
                
            }
        }.navigationViewStyle(.stack)
    }
}

struct ContentView1_Previews: PreviewProvider {
    static var previews: some View {
        ContentView1()
    }
}
